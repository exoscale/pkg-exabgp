#!/usr/bin/env python

import sys

count = 0

while True:
	line = sys.stdin.readline()
	sys.stderr.write(line)
	sys.stderr.flush()
